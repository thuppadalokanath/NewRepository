package testngExamples;

import org.testng.annotations.Test;

public class Ex_testng_1 {
	@Test
	public void login() {
		System.out.println("logoin completed");
	}
	@Test
	public void addEmp() {
		System.out.println("addEmp completed");
	}
	@Test
	public void deleEmp() {
		System.out.println("deleEmp completed");
		
	}
	@Test
	public void emp_firstName() {
		System.out.println("emp firstName completed");
	}
	@Test
	public void emp_lastName() {
		System.out.println("emp lastName completed");
	}
	@Test
	public void logout() {
		System.out.println("logout completed");
	}

}
