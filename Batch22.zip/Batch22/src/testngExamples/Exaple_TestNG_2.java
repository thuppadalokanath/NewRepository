package testngExamples;

import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

public class Exaple_TestNG_2 {
	 @BeforeTest
	public void login() {
		System.out.println("login completed");
	}
	 @Test(priority=1)
	public void addemp() {
		System.out.println("add btn completed");
	}
	 @Test(priority=2)
	public void delemp() {
		System.out.println("delemp completed");
	}
	 @AfterTest
	public void logout() {
		System.out.println("logout btn completed");
	}

}
