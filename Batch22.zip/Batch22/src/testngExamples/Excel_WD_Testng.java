package testngExamples;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.util.Set;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.Reporter;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;

public class Excel_WD_Testng {
	WebDriver driver;
	@BeforeClass
	public void starup() {
		System.setProperty("webdriver.chrome.driver","F:\\Lokanath_Test_Engineer\\ChromeDriver.exe");
		driver=new ChromeDriver();
	}
	@AfterClass
	public void tearDown() {
		driver.close();
	}
	public <Workbook> void tc001() throws Exception {
		
		FileInputStream file=new FileInputStream("F:\\Lokanath_Test_Engineer\\");
		Object Worbook;
		Workbook wb=((Object) Worbook).getWorbook(file);
		Sheet st = ((Object) wb).getSheet(0);
		String un= st.getcell(0,1).getContens();
		String pw= st.getCell(1,1).getContens();
		Reporter.log(un);
		Reporter.log(pw);
		driver.navigate().to("http://183.82.103.245/nareshit/login.php");
		Reporter.log("Application opened");
		driver.findElement(By.name("txtusername")).sendKeys(un);
		driver.findElement(By.name("txtpassword")).sendKeys(pw);
		driver.findElement(By.name("submit")).click();
		Reporter.log("login completed");
		Reporter.log(driver.getTitle());
		driver.findElement(By.linkText("logout")).click();
		
		
	}

}
