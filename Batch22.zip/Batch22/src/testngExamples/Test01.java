package testngExamples;

import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

public class Test01 {
	@BeforeTest
	public void login() {
		System.out.println("login opened");
	}
	@Test
	public void AddEmp() {
		System.out.println("Addemp");
	}
	@AfterTest
	public void FirstNm() {
		System.out.println("emp_fn");
	}
	@Test
	public void Lastnm() {
		System.out.println("last name");
	}
	@Test
	public void Logout() {
		System.out.println("logout application");
		
	}

}
