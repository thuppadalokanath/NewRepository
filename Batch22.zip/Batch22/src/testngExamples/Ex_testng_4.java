package testngExamples;

import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

public class Ex_testng_4 {
	@BeforeMethod
	public void login() {
		System.out.println("login");
	}
	@Test(priority=1)
	public void addEmp() {
		System.out.println("addEmp completed");
	}
	@Test(priority=2)
	public void deleEmp() {
		System.out.println("deleEmp completed");
	}
	@Test(priority=3)
	public void empfirstName() {
		System.out.println("empfirstName completed");
		
	}
	@Test(priority=4)
	public void emplastName() {
		System.out.println("emplastName completed");
	}
	@AfterMethod
	public void logout() {
		System.out.println("logout completed");
	}

}
