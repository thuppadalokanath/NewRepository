package testngExamples;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

public class Example_TestNG {
	@Test
	public void login() {
		System.out.println("login completed");
	}
	@Test
	public void logout() {
		System.out.println("logout complered");
	}
	@Test
	public void add() {
		System.out.println("add button completed");
	}
	@Test
	public void emp() {
		System.out.println("emp completed");
	}

}
