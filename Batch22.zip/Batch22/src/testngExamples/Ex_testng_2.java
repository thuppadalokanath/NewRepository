package testngExamples;

import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

public class Ex_testng_2 {
	@BeforeTest
	public void login() {
		System.out.println("login completed");
	}
	@Test
	public void addEmp() {
		System.out.println("addEmp completed");
	}
	@Test
	public void deleEmp() {
		System.out.println("deleEmp completed");
	}
	@Test
	public void EmpfirstName() {
		System.out.println("empfirstNmae completed");
	}
	@Test
	public void EmplastName() {
		System.out.println("emplastName completed");
	}
	@AfterTest
	public void logout() {
		System.out.println("logout completed");
	}

}
