package testngExamples;

import org.testng.annotations.Test;

public class Exam {
	public static void main(String[] args) {
		
	}
	@Test
	public void login() {
		System.out.println("loke");
		System.out.println();
		System.out.println();
	}
	

}
