package testngExamples;

import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

public class Ex_testng_3 {
	@BeforeClass
	public void login() {
		System.out.println("login completed");
	}
	@Test
	public void addEmp() {
		System.out.println("addEmp completed");
	}
	@Test
	public void delEmp() {
		System.out.println("deleEmp completed");
	}
	@Test
	public void empfirstName() {
		System.out.println("empfirstName completed");
	}
	@Test
	public void empLastName() {
		System.out.println("empLastName completed");
	}
	@AfterClass
	public void logout() {
		System.out.println("logout completedw ");
	}

}
