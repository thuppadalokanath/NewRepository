package Com.hrms.lib;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class General_3 {
//re-usable &function:method
	public void add() {
	System.setProperty("webdriver.chrome.driver","F:\\Lokanath_Test_Engineer\\chromedriver.exe");
	WebDriver driver=new ChromeDriver();
	driver.navigate().to("url");
	System.out.println("open applicationS");
	}
	public void AddnewEmp() {
		WebDriver driver = null;
	
	driver.findElement(By.name("txt_loginname")).sendKeys("nareshit");
	driver.findElement(By.name("txt_xpassword")).sendKeys("ps");
	driver.findElement(By.name("btn_login")).click();	
	}
	public void Firstname() {
		WebDriver driver = ChromeDriver();
		driver.findElement(By.name("txt_Empfirst")).sendKeys("suresh");
		driver.findElement(By.name("txt_Emplast")).sendKeys("selenium");
	}
	private WebDriver ChromeDriver() {
		// TODO Auto-generated method stub
		return null;
	}
	public void Save() {
		WebDriver driver = null;
		driver.findElement(By.name("btn_save")).sendKeys();
	}
	public void closeApplication() {
		WebDriver driver = null;
		driver.findElement(By.linkText("link_logout")).sendKeys();
	}
}
