package Com.hrms.lib;



public class Screen {
	public static void main(String[] args)throws Exception {
		Screen sc=new Screen();
		sc.click ("F:\\Lokanath_Test_Engineer\\Work_Space\\Batch22\\test-output");
		sc.doubleclick("F:\\Lokanath_Test_Engineer\\Work_Space\\Batch22\\test-outputs");
		Thread.sleep(300);
	}

	private void doubleclick(String string) {
		// TODO Auto-generated method stub
		
	}

	private void click(String string) {
		// TODO Auto-generated method stub
		
	}

}
