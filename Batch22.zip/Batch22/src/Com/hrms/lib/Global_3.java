package Com.hrms.lib;
import org.openqa.selenium.WebDriver;

public class Global_3 {
	public WebDriver driver;
	public String url="http:\\183.82.103.245/nareshit/login.php";
	public String ur="nareshit";
	public String pw="nareshit";
	//Object
	public String txt_loginname="txtusername";
	public String txt_password="txtpassword";
	public String btn_login="submit";
	public String add_btn="submit";
	public String txtEmpfistname="suresh";
	public String txtEmplastname="selenium";
	public String save_btn="btnEdit";
	public String link_logout="logout";
	public String link_close="close";

}
