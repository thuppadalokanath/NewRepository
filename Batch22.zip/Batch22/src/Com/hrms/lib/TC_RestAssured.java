package Com.hrms.lib;

import okhttp3.Response;

public class TC_RestAssured {
	public static void main(String[] args) {
		Response res = TC_RestAssured.get("thhps://reqes.in/api/users?page=2");
		int Statuscode = res.getStatusCode();
		System.out.println("statuscode");
		System.out.println("res.getTime()");
		Response res1 = TC_RestAssured.get("thhps://reqes.in/api/users?page=2");
		String det = ((Object) res1).toString();
		System.out.println(det);
		System.out.println(res1.getTime());
	}

	private static Response get(String string) {
		// TODO Auto-generated method stub
		return null;
	}

	
}
