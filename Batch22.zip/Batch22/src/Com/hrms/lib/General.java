package Com.hrms.lib;
import org.openqa.selenium.WebDriver;

import org.openqa.selenium.chrome.ChromeDriver;

import org.openqa.selenium.By;

public class General extends Global{
	public WebDriver driver;
	//Re-usable function/method releted to for whole application
	public void openApplication() {
		System.setProperty("WebDriver.chrome.driver","F:\\Lokanath_Test_Engineer\\chromedriver.exe");
		 driver=new ChromeDriver();
		driver.navigate().to("http://183.82.103.245/nareshit/login.php");
		System.out.println("Application opened");
	}
	public void closeApplication() {
		driver.close();
		System.out.println("Application is closed");
	}
	public void login() {
		driver.findElement(By.name("txt_loginname")).sendKeys("nareshit");
		driver.findElement(By.name("txt_password")).sendKeys("nareshit");
		driver.findElement(By.name("btn_login")).click();
		System.out.println("Login is completed");
	}
	public void logout() {
		
		driver.findElement(By.linkText(link_logout)).click();
		System.out.println("logout completed");
	}

}
