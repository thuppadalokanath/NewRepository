package Com.hrms.lib;
//interivew questions alphabitic oder writen the array program
//this is wrong answer

public class Interivew_questions {
	public static void main(String []args) {
		String[] st= {"cat","dog","elephant","apple"};
		System.out.println(st);
		System.out.println(st[3]);
		System.out.println(st[0]);
		System.out.println(st[1]);
		System.out.println(st[2]);
	}
}
