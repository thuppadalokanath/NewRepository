package Com.hrms.lib;

public class Example {
	public static void main(String []args) {
		final String s3="NIT";
		String s4="Hari";
		s4.concat("krishna");
		System.out.println("Hari");
		StringBuilder sb= new StringBuilder("Hari");
		sb.append("krishna");
		System.out.println(sb);
		
	}
	

}
