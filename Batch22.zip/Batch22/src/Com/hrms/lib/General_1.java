package Com.hrms.lib;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.By;

 class General_0 {
	public WebDriver driver=new ChromeDriver();
	//test date &Objects for whole application
	public String url="http://183.82.103.245/nareshit/login.php";
	public String username="nareshit";
	public String password="nareshit";
	//*****objects
	public String txt_loginname="txtusername";
	public String txt_password="txtpassword";
	public String btn_login="Submit";
	public String link_logout="logout";

}
public class General_1 extends General_0{
	public void openApplication() {
		System.setProperty("webdriver.chrome.driver","F:\\Lokanath_Test_Engineer\\chromedriver.exe");
		WebDriver driver;
		driver=new ChromeDriver();
		driver.navigate().to(url);
		System.out.println("Application opened");
		
	}
	public void closeApplication() {
		driver.close();
		System.out.println("Application closed");
	}
	public void login() {
		driver.findElement(By.name(txt_loginname)).sendKeys("un");
		driver.findElement(By.name(txt_password)).sendKeys("pw");
		driver.findElement(By.name(btn_login)).click();
		System.out.println("login completed");
		
		
	}
	public void logout() {
		driver.findElement(By.linkText(link_logout)).click();
		System.out.println("Logout completed");
	}
}


 class TC001 extends General{
	public static void main(String args[]) {
		General obj=new General();
		obj.openApplication();
		obj.login();
		obj.logout();
		obj.openApplication();
	}
	
}
