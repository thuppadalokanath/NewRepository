package Com.hrms.lib;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;


public class Datebase_Selenium {
	public static void main(String []args) throws Exception {
		String dburl ="jdbc:oracle:thin:@localhost:1521:exe";
		String dbun ="system";
		String dbpw = "admin123";
				
		Connection con=DriverManager.getConnection(dburl,dbun,dbpw);
		Statement st=con.createStatement();
		ResultSet res=st.executeQuery("select*from login");
		While(res.next());{
			String un=res.getString(1);
			String pw=res.getString(2);
			System.setProperty("webdriver.chrome.driver","F//lokanath_Test_Engineer//chromedriver.exe");
			WebDriver driver=new ChromeDriver();
			driver.navigate().to("http://183.82.103.245/nareshit/login.php");
			driver.findElement(By.name("txtUserName")).sendKeys(un);
			driver.findElement(By.name("txtPassword")).sendKeys(pw);
			Thread.sleep(3000);
			driver.findElement(By.name("Submit")).click();
			driver.findElement(By.linkText("logout")).click();
			driver.close();
		}
		res.close();
		st.close();
		con.close();
}

	private static void While(boolean next) {
		// TODO Auto-generated method stub
		
	}
}