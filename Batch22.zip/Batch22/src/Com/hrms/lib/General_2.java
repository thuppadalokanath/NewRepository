package Com.hrms.lib;
import org.openqa.selenium.By;

 
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class General_2 extends Global {
	//re-usable
	private WebDriver driver;
	//private String link_logout;
	public void openApplication() {
		System.setProperty("webdriver.chrome.driver","F:\\Lokanath_Test_Engineer\\chromedriver.exe");
		 driver=new ChromeDriver();
		driver.navigate().to("http://183.82.103.245/nareshit/login.php");
		System.out.println("Application opened");
	}
	public void closeApplication() {
		driver.close();
		System.out.println("Application closed");
	}
public void login() {
	driver.findElement(By.name(txt_loginname)).sendKeys("nareshit");
	driver.findElement(By.name(txt_password)).sendKeys("nareshit");
	driver.findElement(By.name(btn_login)).click();
	System.out.println("login completed");
}
public void logout() {
	driver.findElement(By.linkText(link_logout)).click();
	System.out.println("Logout completed");
}

}
