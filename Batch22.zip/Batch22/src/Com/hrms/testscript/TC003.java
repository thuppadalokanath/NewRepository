package Com.hrms.testscript;

import Com.hrms.lib.General_3;

public class TC003 {
	public static void main(String args[]) {
		Com.hrms.lib.General_3 obj=new Com.hrms.lib.General_3();
		obj.add();
		obj.Firstname();
		obj.AddnewEmp();
		obj.Save();
		obj.closeApplication();
		
	}

}
