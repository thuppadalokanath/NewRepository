package Com.hrms.testscript;

import Com.hrms.lib.General;

public class TC001 {
	public static void main(String[] args) {
		// test ste
		General obj;
		obj=new General();
	obj.openApplication();
		obj.login();
		obj.logout();
		obj.closeApplication();

	}

}
