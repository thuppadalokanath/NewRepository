package Com.hrms.testscript;

import Com.hrms.lib.General_2;

public class TC002 {
	public static void main(String args[]) {
		Com.hrms.lib.General_2 obj=new Com.hrms.lib.General_2();
		obj.openApplication();
		obj.login();
		obj.logout();
		obj.closeApplication();
	}

}
