package upload;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class FileUpload {
	public static void main (String args[]) {
		System.setProperty("webdriver.chrome.driver","F:\\Lokanath_Test_Engineer\\chromedriver.exe");
		WebDriver driver=new ChromeDriver();
		driver.navigate().to("http://127.0.0.1/orangehrm-2.6/login.php");
		driver.findElement(By.xpath("//input[@type='text']")).sendKeys("nareshit");
	}

}
